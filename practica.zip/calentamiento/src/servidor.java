import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.ArrayList;


public class servidor {
	public static String aux="";

	public static void main(String[] args) throws IOException {
		ArrayList<String> probs= leearchivo(args[1]);				
		{
		
		
		servidortcp serv =new servidortcp(Integer.parseInt(args[0]));
		serv.start();
		
		}

		
		
		DatagramSocket socketUDP = new DatagramSocket(
				Integer.parseInt(args[0]));
		byte[] bufer = new byte[1000];
		// Construimos el DatagramPacket para recibir peticiones
		DatagramPacket peticion = new DatagramPacket(bufer,	bufer.length);

	    aux=args[1];
		

        while (true) {
    		// Leemos una petición del DatagramSocket
			socketUDP.receive(peticion);
			
			String str1 = new String(peticion.getData());
		
			
				//obtenemos proverbio
			
		      int numaleatorio = (int) (Math.random()*(probs.size()-1)+1);		    	
			String pro = probs.get(numaleatorio);
				// Construimos el DatagramPacket para enviar la respuesta							
				byte[] proverbi = pro.getBytes();
				DatagramPacket respuesta = new DatagramPacket(proverbi, proverbi.length,	peticion.getAddress(), peticion.getPort());
				// Enviamos la respuesta
				socketUDP.send(respuesta);
 
        }
        } 


	
	

public static ArrayList<String> leearchivo(String archivo) throws FileNotFoundException, IOException {
	
    String proverbio = "";
    ArrayList<String> probs= new ArrayList<String>();
  
    FileReader f = new FileReader(archivo);
    BufferedReader b = new BufferedReader(f);

   
   while (proverbio!=null) {
     proverbio=b.readLine();
     if(proverbio!=null){
  	   probs.add(proverbio);
     }
   }
    

	
	
    int numaleatorio = (int) (Math.random()*(probs.size()-1)+1);
  
    proverbio = probs.get(numaleatorio);;
    b.close();
    return probs;
}
}
