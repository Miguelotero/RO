import static java.lang.System.out;

import java.util.*;
import java.io.*;
import java.net.*;

public class thread extends Thread {
	Socket myClientSocket;
	boolean m_bRunThread = true;

	public thread() {
		super();
	}

	public thread(Socket so) {
		myClientSocket = so;

	}

	public void run() {

		try {
			
			

			BufferedOutputStream buffsalida;
			buffsalida = new BufferedOutputStream(
					myClientSocket.getOutputStream());
			PrintWriter salida = new PrintWriter(buffsalida, false);

			ArrayList<String> probs= servidor.leearchivo(servidor.aux);
			
			int i= (int) (Math.random()*(probs.size()-1)+1);	
			String proverbio = probs.get(i);
		
			salida.println(proverbio );
			salida.flush();
		
			
			

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}