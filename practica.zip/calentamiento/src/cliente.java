import static java.lang.System.out;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

import org.omg.CORBA.portable.InputStream;


public class cliente {

	
	public static void main(String[] args) throws UnknownHostException, IOException {
		
		
	
	
		
		
		
		if(args[0].equals("-tcp")){
			String cadena="";
			Scanner sc=new Scanner(System.in);
			while (true) {
				// Socket cliente; Argumentos: IP y puerto
				System.out.println("introduzca cualquier cosa para recibir un proverbio,Introduzca fin poara termunar conexion");
                  cadena=sc.nextLine();
             
				Socket sock = new Socket(args[1], Integer.parseInt(args[2]));
				
				BufferedReader entrada = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			 	 
				// Imprime respuesta
			    if(cadena.equals("fin")){
              sock.close();
              sc.close();
                  break;}
				
				out.println(entrada.readLine());
			
			
			}
			
		}
		

		
		if(args[0].equals("-udp")){
			
			
			try {
				DatagramSocket socketUDP = new DatagramSocket();
				byte[] mensaje = "hola".getBytes();
				

				InetAddress hostServidor = InetAddress.getByName(args[1]);

				// Construimos un datagrama para enviar el mensaje al servidor
				DatagramPacket peticion = new DatagramPacket(mensaje,
						mensaje.length, hostServidor, Integer.parseInt(args[2]));

				// Enviamos el datagrama
				socketUDP.send(peticion);

				// Construimos el DatagramPacket que contendrá la respuesta
				byte[] bufer = new byte[1000];
				DatagramPacket respuesta = new DatagramPacket(bufer, bufer.length);
				socketUDP.receive(respuesta);		
		        System.out.println(new String(respuesta.getData()));
		        socketUDP.close();
				
				}catch (Exception e){
				System.out.println(e);
			}
			
		}
	
			
}
}
