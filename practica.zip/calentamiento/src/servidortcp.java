import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

	public class servidortcp extends Thread {
		
		int puerto;
		
		public  servidortcp(int puertoaux) {
		puerto=puertoaux;
		
	
		}
	

	public void run(){
	

		try{
			
			ServerSocket server = new ServerSocket(puerto);
			
			Socket so = new Socket();
			while(true) {
				
		    so =server.accept();
			
			thread cliThread = new thread(so);
			cliThread.start();
			}
		}catch (IOException e1) {
			
			e1.printStackTrace();
			
		}
	}
	}
	

